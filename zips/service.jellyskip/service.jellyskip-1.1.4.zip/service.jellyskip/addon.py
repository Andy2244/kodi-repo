import xbmcaddon

addon = xbmcaddon.Addon()
addon.openSettings()
